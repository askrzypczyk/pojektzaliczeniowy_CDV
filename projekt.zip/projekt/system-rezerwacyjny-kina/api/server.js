const express = require("express");
const User = require("./user.model");
const controller = require("./user.controller");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const fs = require('fs');

mongoose.Promise = global.Promise;
mongoose.connect("mongodb://localhost/users_db");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.route("/users")
    .get(controller.authUser)
    .post(controller.createUser);

app.route("/data").get(function(req, res) {
    const rawData = fs.readFileSync('data.json');
    const data = JSON.parse(rawData);
    res.send(data);
});

app.listen(3000);
