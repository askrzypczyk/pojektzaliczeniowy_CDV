const mongoose = require("mongoose");
const User = mongoose.model("Users");

exports.authUser = function(req, res) {
    User.findOne({email: req.query.email, password: req.query.password}, function(err, user) {
        if (!user) {
            res.status(404);
        }
        res.send(user);
    });
};

exports.createUser = function(req, res) {
    const newUser = new User(req.body);
    newUser.save(function(err, user) {
        if (err)
            res.status(409).send(err);
        res.status(201).json(user);
    });
};
