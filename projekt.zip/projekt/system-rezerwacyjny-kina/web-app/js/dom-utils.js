function showElement(selector) {
    const el = document.querySelector(selector);
    el.classList.remove('hidden');
}

function hideElement(selector) {
    const el = document.querySelector(selector);
    el.classList.add('hidden');
}

function setContent(selector, content) {
    const el = document.querySelector(selector);
    el.innerText = content;
}

