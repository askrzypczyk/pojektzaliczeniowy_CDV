/**
 * FORM VALIDATION
 */

// password validation regular expressions
const containsNumber = /\d+/;
const containsUpperCases = /[A-Z]/;
const containsSpecialCharacters = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;

function validatePassword(password) {
    const errors = [];

    if (password.length < 8) {
        errors.push('Hasło powinno zawierać co najmniej 8 znaków.');
    }
    if (!containsNumber.test(password)) {
        errors.push('Hasło powinno zawierać co najmniej jedną cyfrę.');
    }
    if (!containsUpperCases.test(password)) {
        errors.push('Hasło powinno zawierać co najmniej jedną dużą literę.');
    }
    if (!containsSpecialCharacters.test(password)) {
        errors.push('Hasło powinno zawierać co najmniej jeden znak specjalny.');
    }

    return errors;
}

// email validation regular expressions
const emailRegexp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; // source: https://www.w3resource.com/javascript/form/email-validation.php

function validateEmail(email) {
    const errors = [];

    if (!emailRegexp.test(email)) {
        errors.push('Wprowadzono niepoprawny adres e-mail.');
    }

    return errors;
}

/**
 * FORM ERRORS
 */
function updateValidationErrors(errors) {
    if (errors.length) {
        const errorsContainer = document.querySelector('.validation-errors__container')
        errorsContainer.innerHTML = null;
        let errorElement;
        errors.forEach(function (error) {
            errorElement = document.createElement('div');
            errorElement.classList.add('error');
            errorElement.innerText = error;
            errorsContainer.appendChild(errorElement);
        });
        showElement('.validation-errors');
    } else {
        hideElement('.validation-errors');
    }
}
