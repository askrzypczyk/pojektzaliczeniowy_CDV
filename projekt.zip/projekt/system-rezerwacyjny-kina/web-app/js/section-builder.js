function buildSection(sectionKey, data, id) {
    id = parseInt(id);
    const sectionContainer = document.querySelector(`#${sectionKey}Section`);
    const sectionContent = sectionContainer.querySelector('.section__content');

    switch (sectionKey) {
        case SECTIONS.CINEMA:
            buildCinemasSection(sectionContent, data);
            break;
        case SECTIONS.SEANCE:
            const cinemas = data.filter(function(o) {
                return o.cinemaId === id;
            });
            buildSeancesSection(sectionContent, cinemas[0].seances);
            break;
        case SECTIONS.SEATS:
            const seance = data.flatMap(function(o) {
               return o.seances;
            })
            .filter(function(o) {
                return o.seanceId === id;
            })[0];
            buildSeatsSection(sectionContent, data, seance);
            break;
    }
}

function buildCinemasSection(container, cinemas) {
    let containerContent = '';
    cinemas.forEach(cinema => {
        let cinemaElement = `<div class="cinema" data-id="${cinema.cinemaId}">`;
        cinemaElement += `<div class="cinema__name">${cinema.name}</div>`;
        cinemaElement += `<div class="cinema__city">${cinema.city}</div>`;
        const seatsAmount = cinema.seatsRows * cinema.seatsCols;
        cinemaElement += `<div class="cinema__seats">Liczba miejsc: ${seatsAmount}</div>`;
        cinemaElement += `<div class="cinema__seats">Liczba seansów: ${cinema.seances.length}</div>`;
        cinemaElement += '</div>';
        containerContent += cinemaElement;
    });
    container.innerHTML = containerContent;
}

function buildSeancesSection(container, seances) {
    let containerContent = '';
    seances.forEach(seance => {
        let cinemaElement = `<div class="seance" data-id="${seance.seanceId}">`;
        cinemaElement += `<div class="seance__movie">${seance.movieTitle}</div>`;
        cinemaElement += `<div class="seance__datetime">${seance.date} ${seance.time}</div>`;
        cinemaElement += `<div class="seance__duration">Czas trwania: ${seance.duration} min.</div>`;
        cinemaElement += `<div class="seance__price">Cena biletu: ${seance.ticketPrice} PLN</div>`;
        cinemaElement += '</div>';
        containerContent += cinemaElement;
    });
    container.innerHTML = containerContent;
}

function buildSeatsSection(container, data, seance) {
    const cinema = data.filter(function(o) {
        const matchedSeances = o.seances.filter(function(s) {
            return s.seanceId === seance.seanceId;
        });
        return matchedSeances.length > 0;
    })[0];
    let containerContent = '';
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    for (let i = 0; i < cinema.seatsRows; i++) {
        const l = letters[i];
        let row = `<div class="seat__row">`;

        for (let j = 0; j < cinema.seatsCols; j++) {
            row += `<span class="seat__col" data-row="${l}" data-col="${j+1}" data-selected="false">${l}${j+1}</span>`;
        }

        row += `</div>`;
        containerContent += row;
    }
    container.innerHTML = containerContent;
}
