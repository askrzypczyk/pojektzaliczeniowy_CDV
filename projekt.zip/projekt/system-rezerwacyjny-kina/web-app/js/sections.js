const SECTIONS = {
    LOGIN: 'login',
    CINEMA: 'cinema',
    SEANCE: 'seance',
    SEATS: 'seats',
};

const sectionsOrder = [SECTIONS.LOGIN, SECTIONS.CINEMA, SECTIONS.SEANCE, SECTIONS.SEATS];
