const DATA_ENDPOINT = 'http://localhost:3000/data';
const AUTH_ENDPOINT = 'http://localhost:3000/users';

let loggedUser = null;
let activeSection = SECTIONS.LOGIN;
let appData = null;
let selectedCinema = null;
let selectedSeance = null;
let orderedSeatsList = [];

document.addEventListener('DOMContentLoaded', function() {
    initData();

    const loginForm = document.querySelector('#loginForm');
    if (loginForm.attachEvent) {
        loginForm.attachEvent("submit", handleLoginForm);
    } else {
        loginForm.addEventListener("submit", handleLoginForm);
    }
});

function initData() {
    const xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    xhr.overrideMimeType("application/json");
    xhr.open('GET', DATA_ENDPOINT);
    xhr.onreadystatechange = function() {
        if (xhr.readyState > 3 && xhr.status === 200) {
            appData = JSON.parse(xhr.responseText);
        }
    };
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.send();
}

function navigateToNextSection(id) {
    hideElement(`#${activeSection}Section`);
    const hiddenSectionIndex = sectionsOrder.indexOf(activeSection);
    activeSection = sectionsOrder[hiddenSectionIndex + 1];
    showElement(`#${activeSection}Section`);
    buildSection(activeSection, appData, id);
}

function showUserInfo(email) {
    setContent('.user-info__email', email);
    showElement('.user-info');
}

function handleInvalidAuth(status) {
    if (status === 404) { // user was not found in database
        showElement('.auth-error');
    } else { // api/database error
        showElement('.server-error');
    }
}

function handleCinemaSelect() {
    const cinemaElements = document.querySelectorAll('.cinema');
    cinemaElements.forEach(function(el) {
        const cinema = el;
        el.addEventListener('click', function() {
            selectedCinema = appData.filter(function(o) {
                return o.cinemaId === parseInt(cinema.dataset.id);
            })[0];
            navigateToNextSection(cinema.dataset.id);
            handleSeanceSelect();
        });
    });
}

function handleSeanceSelect() {
    const seancesElements = document.querySelectorAll('.seance');
    seancesElements.forEach(function(el) {
        const seance = el;
        el.addEventListener('click', function() {
            selectedSeance = selectedCinema.seances.filter(function(o) {
               return o.seanceId === parseInt(seance.dataset.id);
            })[0];
            navigateToNextSection(seance.dataset.id);
            handleSeatSelect();
            updateCinemaAndSeanceSummary();
        });
    });
}

function updateSeatsSummary() {
    setContent('#orderedSeatsList', orderedSeatsList.join(' '));
    setContent('#orderedTicketsAmount', orderedSeatsList.length);

    const allOrderedTicketsPrice = orderedSeatsList.length * selectedSeance.ticketPrice;
    setContent('#orderedTicketsPrice', allOrderedTicketsPrice);
}

function updateCinemaAndSeanceSummary() {
    setContent('#selectedCinemaName', selectedCinema.name);
    setContent('#selectedMovieTitle', selectedSeance.movieTitle);
    setContent('#selectedSeanceDate', selectedSeance.date);
    setContent('#selectedSeanceTime', selectedSeance.time);
}

function handleSeatSelect() {
    const seatsElements = document.querySelectorAll('.seat__col');
    seatsElements.forEach(function(el) {
        const seat = el;
        el.addEventListener('click', function() {
            const seatName = seat.dataset.row + seat.dataset.col;
            if (seat.dataset.selected === 'true') {
                seat.dataset.selected = 'false';
                seat.classList.remove('seat__col--selected');
                orderedSeatsList = orderedSeatsList.filter(function(o) {
                    return o !== seatName;
                });
            } else {
                seat.dataset.selected = 'true';
                seat.classList.add('seat__col--selected');
                orderedSeatsList.push(seatName);
            }
            updateSeatsSummary();
        });
    });
}

function handleAuthResult(status, responseText) {
    if (status === 200) {
        const result = JSON.parse(responseText);
        loggedUser = result.email;
        showUserInfo(result.email);
        navigateToNextSection();
        handleCinemaSelect();
    } else  {
        handleInvalidAuth(status);
    }
}

function authUser(user) {
    const xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    const url = AUTH_ENDPOINT + '?email=' +  user.email + '&password=' + user.password;
    xhr.open('GET', url);
    xhr.onreadystatechange = function() {
        if (xhr.readyState > 3) {
            handleAuthResult(xhr.status, xhr.responseText);
        }
    };
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.send();
}

function handleLoginForm(e) {
    hideElement('.error');
    hideElement('.user-info');
    if (e.preventDefault) {
        e.preventDefault();
    }
    const formData = new FormData(e.target);
    const user = {
        email: formData.get('email'),
        password: formData.get('password')
    };

    const emailErrors = validateEmail(user.email);
    const passwordErrors = validatePassword(user.password);
    const errors = emailErrors.concat(passwordErrors);
    updateValidationErrors(errors);
    if (errors.length === 0) {
        authUser(user);
    }
    return false;
}
